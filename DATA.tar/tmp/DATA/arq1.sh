#!/bin/bash

echo 'quando nos vênus, juro a marte'

