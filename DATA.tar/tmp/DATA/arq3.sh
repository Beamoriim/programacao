#!/bin/bash

D="$1"
D2="$2"

echo 'exibindo diretórios'
ls ${D} ${D2}

