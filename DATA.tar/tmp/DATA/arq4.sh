#!/bin/bash 

D="$1"
D2="$2"

ls ${D1} ${D2} > /tmp/lista_linda.txt
echo 'Arquivos listados salvos na lista linda!'

